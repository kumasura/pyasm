"""
decorators.py – @asm_func decorator: embed assembly directly in a Python function.

The decorated function's docstring (or body string) is treated as assembly source.
Python args are forwarded to the compiled function; the return type is read from
the decorator parameter.

Usage
-----
    from pyasm import asm_func

    @asm_func(ret='int64')
    def add(a: int, b: int):
        '''
        mov rax, rdi
        add rax, rsi
        ret
        '''

    print(add(3, 4))   # 7
"""

import functools
import inspect
import textwrap
from typing import Callable, Sequence

from .core import AsmFunction


def asm_func(
    ret: str = "int64",
    *,
    argtypes: Sequence = (),
    backend: str = "auto",
    syntax: str = "intel",
):
    """
    Decorator that compiles a function's docstring as x86-64 assembly.

    The Python function body is ignored; only its signature (for documentation)
    and docstring (as assembly source) are used.

    Parameters
    ----------
    ret : str
        Return type string, e.g. 'int64', 'double', 'void'.
    argtypes : sequence
        Explicit ctypes argtypes (inferred from call args if omitted).
    backend : str
        Assembler backend: 'auto', 'keystone', or 'nasm'.
    syntax : str
        'intel' (default) or 'att'.

    Examples
    --------
    @asm_func(ret='int64')
    def multiply(a, b):
        '''
        imul rdi, rsi
        mov  rax, rdi
        ret
        '''

    multiply(6, 7)  # → 42
    """

    def decorator(fn: Callable) -> Callable:
        source = inspect.getdoc(fn)
        if not source:
            raise ValueError(
                f"@asm_func: {fn.__name__} has no docstring to use as assembly source."
            )

        compiled = AsmFunction(
            source,
            ret=ret,
            argtypes=argtypes,
            backend=backend,
            syntax=syntax,
        )

        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            if kwargs:
                raise TypeError("Assembled functions do not accept keyword arguments.")
            return compiled(*args)

        # Attach the underlying AsmFunction for inspection / disassembly
        wrapper.asm = compiled
        wrapper.disassemble = compiled.disassemble
        return wrapper

    return decorator
