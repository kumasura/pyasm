"""
registers.py - Symbolic register name constants + ABI-aware arg helpers.

Use Reg.arg(n) instead of hard-coding rdi/rcx so your assembly source
works on both Linux/macOS (SysV AMD64) and Windows (Microsoft x64).

Example::

    A0, A1 = Reg.arg(0), Reg.arg(1)
    src = "mov rax, " + A0 + "\nadd rax, " + A1 + "\nret"
"""

from .core import ABI, ARG_REGS


class Reg:
    """x86-64 register name constants (lowercase strings)."""

    # 64-bit general purpose
    RAX = "rax"; RBX = "rbx"; RCX = "rcx"; RDX = "rdx"
    RSI = "rsi"; RDI = "rdi"; RSP = "rsp"; RBP = "rbp"
    R8  = "r8";  R9  = "r9";  R10 = "r10"; R11 = "r11"
    R12 = "r12"; R13 = "r13"; R14 = "r14"; R15 = "r15"

    # 32-bit
    EAX = "eax"; EBX = "ebx"; ECX = "ecx"; EDX = "edx"
    ESI = "esi"; EDI = "edi"; ESP = "esp"; EBP = "ebp"

    # 16-bit
    AX = "ax"; BX = "bx"; CX = "cx"; DX = "dx"

    # 8-bit
    AL = "al"; AH = "ah"; BL = "bl"; BH = "bh"
    CL = "cl"; CH = "ch"; DL = "dl"; DH = "dh"

    # Instruction pointer / flags
    RIP = "rip"; RFLAGS = "rflags"

    # XMM (SSE/AVX)
    XMM0  = "xmm0";  XMM1  = "xmm1";  XMM2  = "xmm2";  XMM3  = "xmm3"
    XMM4  = "xmm4";  XMM5  = "xmm5";  XMM6  = "xmm6";  XMM7  = "xmm7"
    XMM8  = "xmm8";  XMM9  = "xmm9";  XMM10 = "xmm10"; XMM11 = "xmm11"
    XMM12 = "xmm12"; XMM13 = "xmm13"; XMM14 = "xmm14"; XMM15 = "xmm15"

    # YMM (AVX)
    YMM0 = "ymm0"; YMM1 = "ymm1"; YMM2 = "ymm2"; YMM3 = "ymm3"

    #: Active ABI string: "sysv" (Linux/macOS) or "win64" (Windows)
    ABI: str = ABI

    #: Ordered tuple of integer argument register names for this platform
    ARGS: tuple = ARG_REGS

    @classmethod
    def arg(cls, n: int) -> str:
        """
        Return the nth (0-indexed) integer argument register name for the
        current platform calling convention.

        SysV AMD64 (Linux/macOS): rdi, rsi, rdx, rcx, r8, r9
        Microsoft x64 (Windows):  rcx, rdx, r8, r9

        Raises ValueError for n beyond the register count (those args
        live on the stack and need manual frame management).
        """
        if n >= len(cls.ARGS):
            raise ValueError(
                f"Argument {n} is not in a register under the {cls.ABI!r} ABI "
                f"(only {len(cls.ARGS)} register args)."
            )
        return cls.ARGS[n]
