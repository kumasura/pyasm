"""
pyasm — Inline x86-64 Assembly for Python
==========================================
Assemble, link, and call raw x86-64 machine code from Python with a clean API.

Backends
--------
* keystone-engine  – assemble at runtime (default, no external tools needed)
* nasm             – fall back / explicit opt-in via asm(..., backend="nasm")

Quick start
-----------
    from pyasm import asm, AsmFunction

    # one-shot call
    result = asm('''
        mov rax, rdi
        add rax, rsi
        ret
    ''', args=(3, 4), ret='int64')
    assert result == 7

    # reusable compiled function
    add = AsmFunction('''
        mov rax, rdi
        add rax, rsi
        ret
    ''', ret='int64')
    print(add(10, 20))   # 30
"""

from .core import AsmFunction, asm
from .decorators import asm_func
from .registers import Reg

__all__ = ["AsmFunction", "asm", "asm_func", "Reg"]
__version__ = "0.1.0"
