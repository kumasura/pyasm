from setuptools import setup, find_packages

setup(
    name="pyasm",
    version="0.1.0",
    description="Inline x86-64 assembly for Python via keystone-engine / nasm",
    author="pyasm contributors",
    python_requires=">=3.9",
    packages=find_packages(),
    install_requires=["keystone-engine"],
    extras_require={
        "disasm": ["capstone"],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: POSIX :: Linux",
        "Topic :: Software Development :: Assemblers",
    ],
)
