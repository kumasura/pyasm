"""
examples.py - pyasm usage showcase (cross-platform: Linux / macOS / Windows)
Run:  python examples.py

All assembly uses Reg.arg(n) so the correct ABI register is used
automatically (rdi/rsi on Linux+macOS, rcx/rdx on Windows).
"""

import sys, platform
sys.path.insert(0, ".")

from pyasm import asm, AsmFunction, asm_func, Reg
import pyasm.core as _core

print("=" * 60)
print(f"  pyasm - Inline x86-64 Assembly for Python")
print(f"  Platform : {platform.system()}  ABI: {Reg.ABI}")
print(f"  arg regs : {Reg.ARGS}")
print("=" * 60)

A0 = Reg.arg(0)
A1 = Reg.arg(1)

# ------------------------------------------------------------------
# 1. One-shot asm() - add two integers
# ------------------------------------------------------------------
print("\n[1] One-shot asm() - add two integers")
result = asm(f"""
    mov rax, {A0}
    add rax, {A1}
    ret
""", args=(3, 4), ret="int64")
print(f"    3 + 4 = {result}")
assert result == 7, f"Expected 7, got {result}"

# ------------------------------------------------------------------
# 2. Reusable AsmFunction - multiply
# ------------------------------------------------------------------
print("\n[2] Reusable AsmFunction - multiply")
mul = AsmFunction(f"""
    imul {A0}, {A1}
    mov  rax, {A0}
    ret
""", ret="int64")
print(f"    6 x 7 = {mul(6, 7)}")
assert mul(6, 7) == 42

# ------------------------------------------------------------------
# 3. @asm_func decorator - subtract
#    The docstring is the asm source, built with f-string beforehand.
# ------------------------------------------------------------------
print("\n[3] @asm_func decorator - subtract")

_sub_src = f"mov rax, {A0}\nsub rax, {A1}\nret"

@asm_func(ret="int64")
def subtract(a: int, b: int):
    "mov rax, rdi\nsub rax, rsi\nret"   # placeholder, overwritten below

# Patch with correct ABI source
subtract.asm._code = _core._assemble(_sub_src, "auto")
subtract.asm._addr, subtract.asm._mem = _core._alloc_exec(subtract.asm._code)
subtract.asm._cfunc = None

print(f"    10 - 3 = {subtract(10, 3)}")
assert subtract(10, 3) == 7

# ------------------------------------------------------------------
# 4. Return a constant - no arguments
# ------------------------------------------------------------------
print("\n[4] Return constant 42")
fortytwo = AsmFunction("mov rax, 42\nret", ret="int64")
print(f"    result = {fortytwo()}")
assert fortytwo() == 42

# ------------------------------------------------------------------
# 5. Bitwise AND
# ------------------------------------------------------------------
print("\n[5] Bitwise AND")
band = AsmFunction(f"""
    mov rax, {A0}
    and rax, {A1}
    ret
""", ret="int64")
print(f"    0xFF & 0x0F = {band(0xFF, 0x0F):#04x}")
assert band(0xFF, 0x0F) == 0x0F

# ------------------------------------------------------------------
# 6. Reg.arg() dynamic source generation
# ------------------------------------------------------------------
print("\n[6] Reg.arg() - dynamic source generation")
src = f"mov rax, {Reg.arg(0)}\nadd rax, {Reg.arg(1)}\nret"
dynamic_add = AsmFunction(src, ret="int64")
print(f"    100 + 200 = {dynamic_add(100, 200)}")
assert dynamic_add(100, 200) == 300

# ------------------------------------------------------------------
# 7. Disassembly via capstone
# ------------------------------------------------------------------
print("\n[7] Disassembly (capstone)")
print(mul.disassemble())

# ------------------------------------------------------------------
# 8. Iterative Fibonacci
#    Use r10/r11 as scratch (caller-saved on both ABIs, not arg regs)
#    so we avoid clobbering rcx which is arg(0) on Windows.
# ------------------------------------------------------------------
print("\n[8] Iterative Fibonacci")
fib = AsmFunction(f"""
    mov  r10, {A0}
    cmp  r10, 1
    jle  fib_base
    mov  rax, 0
    mov  rbx, 1
    mov  r11, r10
fib_loop:
    mov  rdx, rbx
    add  rdx, rax
    mov  rax, rbx
    mov  rbx, rdx
    dec  r11
    cmp  r11, 1
    jg   fib_loop
    mov  rax, rbx
    ret
fib_base:
    mov  rax, r10
    ret
""", ret="int64")

expected = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55]
for i in range(11):
    v = fib(i)
    print(f"    fib({i:2d}) = {v}")
    assert v == expected[i], f"fib({i}): expected {expected[i]}, got {v}"

print("\nAll assertions passed.")
