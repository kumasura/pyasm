"""
examples.py – pyasm usage showcase
Run:  python examples.py
"""

import sys
sys.path.insert(0, ".")

from pyasm import asm, AsmFunction, asm_func, Reg


print("=" * 60)
print("  pyasm — Inline x86-64 Assembly for Python")
print("=" * 60)

# ------------------------------------------------------------------
# 1. One-shot asm() call
# ------------------------------------------------------------------
print("\n[1] One-shot asm() – add two integers")
result = asm("""
    mov rax, rdi
    add rax, rsi
    ret
""", args=(3, 4), ret="int64")
print(f"    3 + 4 = {result}")
assert result == 7

# ------------------------------------------------------------------
# 2. Reusable AsmFunction
# ------------------------------------------------------------------
print("\n[2] Reusable AsmFunction – multiply")
mul = AsmFunction("""
    imul rdi, rsi
    mov  rax, rdi
    ret
""", ret="int64")
print(f"    6 × 7 = {mul(6, 7)}")
assert mul(6, 7) == 42

# ------------------------------------------------------------------
# 3. @asm_func decorator
# ------------------------------------------------------------------
print("\n[3] @asm_func decorator – subtract")

@asm_func(ret="int64")
def subtract(a: int, b: int):
    """
    mov rax, rdi
    sub rax, rsi
    ret
    """

print(f"    10 - 3 = {subtract(10, 3)}")
assert subtract(10, 3) == 7

# ------------------------------------------------------------------
# 4. Return a constant (no arguments)
# ------------------------------------------------------------------
print("\n[4] Return constant 42")
fortytwo = AsmFunction("mov rax, 42\nret", ret="int64")
print(f"    result = {fortytwo()}")
assert fortytwo() == 42

# ------------------------------------------------------------------
# 5. Bitwise AND
# ------------------------------------------------------------------
print("\n[5] Bitwise AND")
band = AsmFunction("""
    mov rax, rdi
    and rax, rsi
    ret
""", ret="int64")
print(f"    0xFF & 0x0F = {band(0xFF, 0x0F):#04x}")
assert band(0xFF, 0x0F) == 0x0F

# ------------------------------------------------------------------
# 6. Using Reg constants
# ------------------------------------------------------------------
print("\n[6] Using Reg constants to build source programmatically")
src = f"mov {Reg.RAX}, {Reg.RDI}\nadd {Reg.RAX}, {Reg.RSI}\nret"
dynamic_add = AsmFunction(src, ret="int64")
print(f"    100 + 200 = {dynamic_add(100, 200)}")
assert dynamic_add(100, 200) == 300

# ------------------------------------------------------------------
# 7. Disassembly
# ------------------------------------------------------------------
print("\n[7] Disassembly (via capstone)")
print(mul.disassemble())

# ------------------------------------------------------------------
# 8. Fibonacci (iterative loop in asm)
# ------------------------------------------------------------------
print("\n[8] Iterative Fibonacci in assembly")
fib = AsmFunction("""
    cmp rdi, 1
    jle fib_base
    mov rax, 0
    mov rbx, 1
    mov rcx, rdi
fib_loop:
    mov rdx, rbx
    add rdx, rax
    mov rax, rbx
    mov rbx, rdx
    dec rcx
    cmp rcx, 1
    jg fib_loop
    mov rax, rbx
    ret
fib_base:
    mov rax, rdi
    ret
""", ret="int64")

expected = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55]
for i in range(11):
    v = fib(i)
    print(f"    fib({i:2d}) = {v}")
    assert v == expected[i], f"fib({i}) expected {expected[i]}, got {v}"

print("\nAll assertions passed. ✓")
