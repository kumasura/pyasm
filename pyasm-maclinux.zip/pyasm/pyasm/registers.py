"""
registers.py – Symbolic register name constants.

Useful when building assembly strings programmatically.

    from pyasm.registers import Reg
    src = f"mov rax, {Reg.RDI}\\nadd rax, {Reg.RSI}\\nret"
"""


class _RegMeta(type):
    """Makes Reg.RAX == 'rax' (string value)."""
    pass


class Reg(metaclass=_RegMeta):
    """x86-64 register name constants (lowercase strings)."""

    # 64-bit general purpose
    RAX = "rax"; RBX = "rbx"; RCX = "rcx"; RDX = "rdx"
    RSI = "rsi"; RDI = "rdi"; RSP = "rsp"; RBP = "rbp"
    R8  = "r8";  R9  = "r9";  R10 = "r10"; R11 = "r11"
    R12 = "r12"; R13 = "r13"; R14 = "r14"; R15 = "r15"

    # 32-bit
    EAX = "eax"; EBX = "ebx"; ECX = "ecx"; EDX = "edx"
    ESI = "esi"; EDI = "edi"; ESP = "esp"; EBP = "ebp"

    # 16-bit
    AX = "ax"; BX = "bx"; CX = "cx"; DX = "dx"

    # 8-bit
    AL = "al"; AH = "ah"; BL = "bl"; BH = "bh"
    CL = "cl"; CH = "ch"; DL = "dl"; DH = "dh"

    # Instruction pointer / flags
    RIP = "rip"; RFLAGS = "rflags"

    # XMM (SSE/AVX)
    XMM0  = "xmm0";  XMM1  = "xmm1";  XMM2  = "xmm2";  XMM3  = "xmm3"
    XMM4  = "xmm4";  XMM5  = "xmm5";  XMM6  = "xmm6";  XMM7  = "xmm7"
    XMM8  = "xmm8";  XMM9  = "xmm9";  XMM10 = "xmm10"; XMM11 = "xmm11"
    XMM12 = "xmm12"; XMM13 = "xmm13"; XMM14 = "xmm14"; XMM15 = "xmm15"

    # YMM (AVX)
    YMM0  = "ymm0";  YMM1  = "ymm1";  YMM2  = "ymm2";  YMM3  = "ymm3"

    # System V AMD64 calling convention argument registers (in order)
    ARGS = ("rdi", "rsi", "rdx", "rcx", "r8", "r9")

    @classmethod
    def arg(cls, n: int) -> str:
        """Return the nth (0-indexed) integer argument register name."""
        if n >= len(cls.ARGS):
            raise ValueError(
                f"x86-64 SysV ABI only passes {len(cls.ARGS)} args in registers; "
                f"arg {n} would be on the stack."
            )
        return cls.ARGS[n]
