"""
core.py – assemble x86-64 source → executable memory → callable Python object.
"""

import ctypes
import ctypes.util
import mmap
import os
import subprocess
import tempfile
import textwrap
from typing import Any, Sequence

# ---------------------------------------------------------------------------
# Return-type map
# ---------------------------------------------------------------------------
_RET_CTYPES = {
    "int8":   ctypes.c_int8,
    "int16":  ctypes.c_int16,
    "int32":  ctypes.c_int32,
    "int64":  ctypes.c_int64,
    "uint8":  ctypes.c_uint8,
    "uint16": ctypes.c_uint16,
    "uint32": ctypes.c_uint32,
    "uint64": ctypes.c_uint64,
    "float":  ctypes.c_float,
    "double": ctypes.c_double,
    "void":   None,
    "ptr":    ctypes.c_void_p,
    "bool":   ctypes.c_bool,
}

# ---------------------------------------------------------------------------
# Assembler backends
# ---------------------------------------------------------------------------

def _assemble_keystone(source: str) -> bytes:
    try:
        import keystone
    except ImportError:
        raise ImportError(
            "keystone-engine is not installed. "
            "Run: pip install keystone-engine"
        )
    ks = keystone.Ks(keystone.KS_ARCH_X86, keystone.KS_MODE_64)
    encoding, count = ks.asm(source)
    if encoding is None:
        raise ValueError("Keystone: assembly failed (returned None)")
    return bytes(encoding)


def _assemble_nasm(source: str) -> bytes:
    nasm_src = (
        "BITS 64\n"
        "section .text\n"
        "global _start\n"
        "_start:\n"
        + textwrap.dedent(source)
    )
    with tempfile.TemporaryDirectory() as tmp:
        src_path = os.path.join(tmp, "src.asm")
        out_path = os.path.join(tmp, "out.bin")
        with open(src_path, "w") as f:
            f.write(nasm_src)
        result = subprocess.run(
            ["nasm", "-f", "bin", "-o", out_path, src_path],
            capture_output=True, text=True
        )
        if result.returncode != 0:
            raise ValueError(f"NASM error:\n{result.stderr}")
        with open(out_path, "rb") as f:
            return f.read()


def _assemble(source: str, backend: str) -> bytes:
    """Dispatch to the requested assembler backend."""
    if backend == "auto":
        # Prefer keystone (no subprocess); fall back to nasm
        try:
            return _assemble_keystone(source)
        except ImportError:
            return _assemble_nasm(source)
    elif backend == "keystone":
        return _assemble_keystone(source)
    elif backend == "nasm":
        return _assemble_nasm(source)
    else:
        raise ValueError(f"Unknown backend '{backend}'. Choose: auto, keystone, nasm")


# ---------------------------------------------------------------------------
# Executable memory helpers
# ---------------------------------------------------------------------------

def _alloc_exec(code: bytes) -> ctypes.c_void_p:
    """Copy *code* into an rwx mmap region and return its address."""
    size = len(code)
    # Allocate anonymous executable memory
    mem = mmap.mmap(-1, size, prot=mmap.PROT_READ | mmap.PROT_WRITE | mmap.PROT_EXEC)
    mem.write(code)
    mem.seek(0)
    # Keep a reference so GC doesn't collect it
    addr = ctypes.addressof(ctypes.c_char.from_buffer(mem))
    return addr, mem   # caller must keep `mem` alive


# ---------------------------------------------------------------------------
# AsmFunction
# ---------------------------------------------------------------------------

class AsmFunction:
    """
    A compiled, reusable x86-64 function callable from Python.

    Parameters
    ----------
    source : str
        x86-64 assembly source (AT&T or Intel syntax, auto-detected by keystone).
    ret : str
        Return type name. One of: int8/16/32/64, uint8/16/32/64,
        float, double, void, ptr, bool.  Default 'int64'.
    argtypes : sequence of ctypes types, optional
        Argument types for the generated cfunctype.  Defaults to
        ``[ctypes.c_int64] * n`` where *n* is the number of positional
        args passed on the first call.
    backend : str
        'auto' (default), 'keystone', or 'nasm'.
    syntax : str
        'intel' (default) or 'att'.  Passed to keystone.

    Examples
    --------
    >>> from pyasm import AsmFunction
    >>> mul = AsmFunction('''
    ...     imul rdi, rsi
    ...     mov  rax, rdi
    ...     ret
    ... ''', ret='int64')
    >>> mul(6, 7)
    42
    """

    def __init__(
        self,
        source: str,
        *,
        ret: str = "int64",
        argtypes: Sequence = (),
        backend: str = "auto",
        syntax: str = "intel",
    ):
        self.source = textwrap.dedent(source).strip()
        self.ret = ret
        self._argtypes = list(argtypes)
        self.backend = backend
        self.syntax = syntax

        # Assemble
        self._code = _assemble(self._preprocess(self.source), backend)

        # Map into executable memory
        self._addr, self._mem = _alloc_exec(self._code)

        # Build ctypes function prototype
        self._cfunc = None  # built lazily on first call if argtypes not given

        if self._argtypes:
            self._cfunc = self._make_cfunc(self._argtypes)

    # ------------------------------------------------------------------
    def _preprocess(self, src: str) -> str:
        """Inject preamble expected by keystone (Intel syntax directive)."""
        if self.backend in ("auto", "keystone") and self.syntax == "intel":
            # keystone wants raw Intel syntax without a directive
            return src
        return src

    def _make_cfunc(self, argtypes):
        restype = _RET_CTYPES.get(self.ret)
        if self.ret not in _RET_CTYPES:
            raise ValueError(
                f"Unknown return type '{self.ret}'. "
                f"Valid: {list(_RET_CTYPES)}"
            )
        proto = ctypes.CFUNCTYPE(restype, *argtypes)
        return proto(self._addr)

    # ------------------------------------------------------------------
    def __call__(self, *args):
        if self._cfunc is None:
            # Auto-infer argtypes from the Python args on first call
            self._argtypes = [_py_to_ctype(a) for a in args]
            self._cfunc = self._make_cfunc(self._argtypes)
        return self._cfunc(*args)

    # ------------------------------------------------------------------
    def disassemble(self) -> str:
        """Return a human-readable disassembly using capstone."""
        try:
            import capstone
        except ImportError:
            return "(install capstone for disassembly: pip install capstone)"
        md = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64)
        lines = []
        for i in md.disasm(self._code, 0x0):
            lines.append(f"  0x{i.address:04x}:  {i.mnemonic:<8} {i.op_str}")
        return "\n".join(lines) or "(no instructions)"

    def __repr__(self):
        return (
            f"<AsmFunction ret={self.ret!r} "
            f"bytes={len(self._code)} backend={self.backend!r}>"
        )


# ---------------------------------------------------------------------------
# Convenience one-shot function
# ---------------------------------------------------------------------------

def asm(
    source: str,
    *,
    args: Sequence[Any] = (),
    ret: str = "int64",
    argtypes: Sequence = (),
    backend: str = "auto",
    syntax: str = "intel",
) -> Any:
    """
    Assemble *source*, call it with *args*, and return the result.

    This is a one-shot convenience wrapper around :class:`AsmFunction`.
    For hot paths, create an ``AsmFunction`` once and reuse it.

    Parameters
    ----------
    source : str
        x86-64 assembly source.
    args : tuple
        Arguments forwarded to the assembled function.
    ret : str
        Return type string (default 'int64').
    argtypes : sequence
        Explicit ctypes argtypes (optional).
    backend : str
        'auto', 'keystone', or 'nasm'.
    syntax : str
        'intel' or 'att'.

    Examples
    --------
    >>> from pyasm import asm
    >>> asm('mov rax, 42 \\n ret', ret='int64')
    42
    """
    fn = AsmFunction(
        source, ret=ret, argtypes=argtypes, backend=backend, syntax=syntax
    )
    return fn(*args)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _py_to_ctype(value):
    """Guess the ctypes type for a Python value (best-effort)."""
    if isinstance(value, bool):
        return ctypes.c_bool
    if isinstance(value, int):
        return ctypes.c_int64
    if isinstance(value, float):
        return ctypes.c_double
    if isinstance(value, ctypes._SimpleCData):
        return type(value)
    # Fallback: pass as 64-bit int (pointer-sized)
    return ctypes.c_int64
